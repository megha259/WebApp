﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.Models;

namespace WebApplication.Controllers
{
    public class UserController : Controller
    {
        private readonly UserContext _Db;

        public UserController(UserContext Db)
        {
            _Db = Db;
        }

        public IActionResult Create(UserForm obj)
        {
            LoadDDL();
            return View(obj);
        }
        [HttpPost]
         
        public async Task<IActionResult> AddUser(UserForm obj)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (obj.UserID == 0)
                    {
                        _Db.UserInfo.Add(obj);
                        await _Db.SaveChangesAsync();
                    }
                    else
                    {
                        _Db.Entry(obj).State = EntityState.Modified;
                        await _Db.SaveChangesAsync();

                    }
                }
                return View();
            }
            catch(Exception)
            {
                return RedirectToAction("UserList");
            }
        }

        private void LoadDDL()
        {
            try
            {
                List<UserForm> usrList = new List<UserForm>();
                usrList = _Db.UserInfo.ToList();
                usrList.Insert(0, new UserForm { UserID = 0 });
                ViewBag.UsrList = usrList;
            }
            catch (Exception)
            {

            }
        }

        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var usr = await _Db.UserInfo.FindAsync(id);
                if(usr != null){
                    _Db.UserInfo.Remove(usr);
                    await _Db.SaveChangesAsync();
                }
                return RedirectToAction("UserList");
            }
            catch(Exception )
            {
                return RedirectToAction("UserList");
            }
        }

        public IActionResult UserList()
        {
            try
            {
                var usrList = _Db.UserInfo.ToList();
                return View(usrList);

            }
            catch (Exception)
            {
                return View();
            }
        }
    }
}
